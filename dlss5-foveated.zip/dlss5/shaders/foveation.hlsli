// Foveated NR working grid (horizontal warp).
//
// DLSSNR is a same-resolution network, so a spatially varying working
// resolution is expressed as a warp: the frame is resampled into a narrower
// working image whose horizontal pixel density is 1 (relative to the uniform
// working scale) inside a central plateau, falls along a smoothstep ramp, and
// settles at Edge on both sides.  The model runs once on the warped image with
// warped guides (fov_guides), and every stage that maps between the working
// grid and the full grid goes through FovWarp / FovUnwarp.  The vertical axis
// is never warped.
//
// Coordinates are normalized: n in [0, 1] across the full (unwarped) image,
// v in [0, 1] across the working (warped) image.  Both functions extend
// linearly past [0, 1] so off-screen reprojection stays well defined.
//
// Packed parameter (one dword, foveation.hpp mirrors it):
//   bits  0..9  Center: half-width of the density-1 plateau, fraction of the
//               half-frame (0.5 = the central 50% of the width)
//   bits 10..19 Ramp:   width of the smoothstep fall-off, same units
//   bits 20..29 Edge:   density outside the ramp (0.5 = half resolution)
//   bit  31     enabled
// 0 means off and every helper below collapses to the uniform mapping.

#ifndef DLSS5_FOVEATION_HLSLI
#define DLSS5_FOVEATION_HLSLI

struct FovParams {
  float a;     // plateau half-width
  float b;     // ramp width
  float k;     // 1 - Edge
  float e;     // Edge
  float gmax;  // FovG(1)
};

bool FovEnabled(uint packed) {
  return (packed & 0x80000000u) != 0u;
}

// G(tau): integral of the density over [0, tau], tau = |2n - 1|.
float FovG(float tau, FovParams p) {
  if (tau <= p.a) return tau;
  const float ramp_end = p.a + p.b;
  const float ramp_area = p.b * (1.0 - 0.5 * p.k);
  if (tau >= ramp_end) return p.a + ramp_area + p.e * (tau - ramp_end);
  const float q = (tau - p.a) / p.b;
  const float q2 = q * q;
  return p.a + p.b * (q - p.k * (q2 * q - 0.5 * q2 * q2));
}

FovParams FovDecode(uint packed) {
  FovParams p;
  p.a = float(packed & 1023u) / 1023.0;
  p.b = min(float((packed >> 10) & 1023u) / 1023.0, 1.0 - p.a);
  p.e = clamp(float((packed >> 20) & 1023u) / 1023.0, 0.05, 1.0);
  p.k = 1.0 - p.e;
  p.gmax = 1.0;
  p.gmax = FovG(1.0, p);
  return p;
}

// Inverse of FovG.  The ramp segment h(q) = q - k(q^3 - q^4/2) has
// h'(q) = 1 - k * smoothstep(q) >= Edge > 0, so Newton from q = r converges
// in a handful of steps; six is far below float precision for Edge >= 0.05.
float FovGInv(float g, FovParams p) {
  if (g <= p.a) return g;
  const float ramp_area = p.b * (1.0 - 0.5 * p.k);
  if (g >= p.a + ramp_area) return p.a + p.b + (g - p.a - ramp_area) / p.e;
  const float r = (g - p.a) / p.b;
  float q = r;
  [unroll]
  for (int i = 0; i < 6; ++i) {
    const float q2 = q * q;
    const float h = q - p.k * (q2 * q - 0.5 * q2 * q2) - r;
    const float dh = 1.0 - p.k * (3.0 * q2 - 2.0 * q2 * q);
    q = saturate(q - h / dh);
  }
  return p.a + p.b * q;
}

// Full-grid normalized x -> working-grid normalized x.
float FovWarp(float n, uint packed) {
  if (!FovEnabled(packed)) return n;
  const FovParams p = FovDecode(packed);
  const float t = 2.0 * n - 1.0;
  return 0.5 + 0.5 * sign(t) * FovG(abs(t), p) / p.gmax;
}

// Working-grid normalized x -> full-grid normalized x.
float FovUnwarp(float v, uint packed) {
  if (!FovEnabled(packed)) return v;
  const FovParams p = FovDecode(packed);
  const float s = 2.0 * v - 1.0;
  return 0.5 + 0.5 * sign(s) * FovGInv(abs(s) * p.gmax, p);
}

// Continuous texel position on a `dst` grid of the pixel CENTER `pixel` on a
// `src` grid, for a src -> working mapping (src is the full grid).  The
// uniform form is (pixel + 0.5) * dst / src - 0.5.
float FovFullToWorkPos(uint pixel, uint src, uint dst, uint packed) {
  return FovWarp((float(pixel) + 0.5) / float(src), packed) * float(dst) - 0.5;
}

// Full-grid extent [x0, x1) covered by working texel `pixel` (working grid of
// `work` texels over a full grid of `full` texels): the encode footprint.
float2 FovWorkFootprint(uint pixel, uint work, uint full, uint packed) {
  const float x0 = FovUnwarp(float(pixel) / float(work), packed) * float(full);
  const float x1 = FovUnwarp(float(pixel + 1u) / float(work), packed) * float(full);
  return float2(x0, x1);
}

#endif  // DLSS5_FOVEATION_HLSLI
