// Foveated NR working grid - host side.  Mirrors shaders/foveation.hlsli:
// the packed dword, the density integral G and the working-width factor.
// Change the two together.
//
// The NR model is same-resolution, so "foveated" means a horizontal warp of
// the working image: density 1 in a central plateau, a smoothstep fall-off,
// Edge on both sides.  One NR evaluate, one temporal history, no tile seams.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace foveation {

inline constexpr uint32_t kEnabledBit = 0x80000000u;
inline constexpr uint32_t kFieldMax = 1023u;

// Player-facing limits.  Edge below 25% starts to show as smeared NR edits
// on the far sides; Center/Ramp are fractions of the half-frame.
inline constexpr float kMinEdge = 0.25f;
inline constexpr float kMaxEdge = 1.f;

struct Params {
  float center = 0.5f;  // half-width of the density-1 plateau, of the half-frame
  float ramp = 0.25f;   // smoothstep fall-off width, of the half-frame
  float edge = 0.5f;    // density outside the ramp
};

inline uint32_t Quantize(float value) {
  return static_cast<uint32_t>(
      std::lround(std::clamp(value, 0.f, 1.f) * static_cast<float>(kFieldMax)));
}

// The exact parameters the shaders decode from a packed dword.
struct Decoded {
  double a = 0.0;
  double b = 0.0;
  double e = 1.0;
  double k = 0.0;
  double gmax = 1.0;
};

inline double G(double tau, const Decoded& p) {
  if (tau <= p.a) return tau;
  const double ramp_end = p.a + p.b;
  const double ramp_area = p.b * (1.0 - 0.5 * p.k);
  if (tau >= ramp_end) return p.a + ramp_area + p.e * (tau - ramp_end);
  const double q = (tau - p.a) / p.b;
  const double q2 = q * q;
  return p.a + p.b * (q - p.k * (q2 * q - 0.5 * q2 * q2));
}

inline Decoded Decode(uint32_t packed) {
  Decoded p;
  if ((packed & kEnabledBit) == 0u) return p;
  p.a = static_cast<double>(packed & kFieldMax) / kFieldMax;
  p.b = std::min(static_cast<double>((packed >> 10) & kFieldMax) / kFieldMax, 1.0 - p.a);
  p.e = std::clamp(static_cast<double>((packed >> 20) & kFieldMax) / kFieldMax, 0.05, 1.0);
  p.k = 1.0 - p.e;
  p.gmax = G(1.0, p);
  return p;
}

// 0 = off.  Ramp is clipped so the plateau plus the ramp never exceed the
// half-frame; an Edge of 1 is the identity warp and packs as off.
inline uint32_t Pack(bool enabled, const Params& params) {
  if (!enabled) return 0u;
  const float edge = std::clamp(params.edge, kMinEdge, kMaxEdge);
  if (edge >= kMaxEdge) return 0u;
  const float center = std::clamp(params.center, 0.f, 1.f);
  const float ramp = std::clamp(params.ramp, 0.f, 1.f - center);
  if (center >= 1.f) return 0u;
  return kEnabledBit | Quantize(center) | (Quantize(ramp) << 10) | (Quantize(edge) << 20);
}

// Working width over the uniform working width: the mean density.  The
// warped image keeps density 1 at the centre because the working width is
// exactly this fraction of the uniform one.
inline double WidthFactor(uint32_t packed) {
  return (packed & kEnabledBit) != 0u ? Decode(packed).gmax : 1.0;
}

inline uint32_t WarpedWidth(uint32_t uniform_width, uint32_t packed) {
  if ((packed & kEnabledBit) == 0u) return uniform_width;
  const double width = static_cast<double>(uniform_width) * WidthFactor(packed);
  return std::max<uint32_t>(16u, static_cast<uint32_t>(std::lround(width)));
}

// Normalized full x -> normalized working x (diagnostics and tests).
inline double Warp(double n, uint32_t packed) {
  if ((packed & kEnabledBit) == 0u) return n;
  const Decoded p = Decode(packed);
  const double t = 2.0 * n - 1.0;
  const double s = t < 0.0 ? -1.0 : (t > 0.0 ? 1.0 : 0.0);
  return 0.5 + 0.5 * s * G(std::abs(t), p) / p.gmax;
}

}  // namespace foveation
